for i in range(1,51): #runs loop 50 times, from numbers 1 to 50
    if i % 5 == 0 and i % 3 == 0:
        print(i, "is divisible by both 5 and 3")
    elif i % 5 == 0: #Checks to see if the current loop is divisible by 5 by  checking the remainder
        print(i, "is divisible by 5")
    elif i % 3 == 0:
        print(i, "is divisible by 3")
    else:
        print(i) #prints current loop number
