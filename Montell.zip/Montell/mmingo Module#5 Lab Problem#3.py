import turtle

blue = turtle.Turtle()


sides = int(input("how many sides can i have to create a regular polygon "))
shapes = int(input("how long do you want each side? "))
blue.color(input("what color do you want? "))
blue.fillcolor(input("what do you want your fillcolor to be? "))

blue.begin_fill()
for i in range(0,sides):
    blue.forward(shapes)
    blue.right(360 / sides)
blue.end_fill()
