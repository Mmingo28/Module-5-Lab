#input(12,10,32,3,66,17,42,99,20)
#print 12,10,32,3,66,17,42,99,20

myList=[12,10,32,3,66,17,42,99,20]
for item in myList:
    print(item)
    print(item*item)
