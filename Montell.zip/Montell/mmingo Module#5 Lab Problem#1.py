#input("Hello World")
#Print Hello world

for numbers in range(0,100):
     print("Hello World")

     
